MMIC V-Sync Prototype v0.4.3 — MENGINE Crash Detection Sensors
===============================================================

Purpose
-------
v0.4.3 is based on the tested v0.4.2 scheduler. It adds event-driven graphics
fault detection and a stable set of Scratch reporters for MENGINE's existing
crash detector. It does NOT take over MENGINE's severity policy, save handling,
IndexedDB protection, component restarts, alerts, or page shutdown decisions.

Important preserved behavior
----------------------------
- VM execution remains configured by the project (keep MMIC at 240 TPS).
- No interpolation is introduced or enabled.
- HQ Pen quality and drawing behavior are not changed.
- The requestAnimationFrame scheduler and resize redraw behavior remain.
- No recurring diagnostic timer is added.
- The extension does NOT call WebGL getError(); that method consumes the shared
  WebGL error queue and could interfere with other renderer diagnostics.

New crash-detector interface
----------------------------
Poll these blocks from MENGINE at its existing 10-frame cadence:

1. graphics fault pending?             BOOLEAN
2. graphics fault severity level       NUMBER, 0–8 (0 = none; 1–8 match MENGINE levels)
3. graphics fault code                 TEXT
4. graphics fault message              TEXT
5. graphics fault sequence number      NUMBER, monotonic event ID
6. unacknowledged graphics fault count NUMBER
7. graphics fault details JSON         TEXT, selected highest-severity fault
8. graphics fault history JSON         TEXT, last 16 recorded faults
9. acknowledge current graphics faults COMMAND
10. acknowledge graphics faults through sequence [SEQUENCE] COMMAND
11. WebGL context lost?                BOOLEAN
12. renderer exception detected?       BOOLEAN
13. graphics failsafe active?          BOOLEAN
14. graphics health state              TEXT
15. last renderer draw duration ms     NUMBER
16. maximum renderer draw duration ms  NUMBER
17. last draw request to RAF delay ms  NUMBER
18. maximum draw request to RAF delay  NUMBER
19. slow renderer draw count           NUMBER
20. visible-tab rendering stall count  NUMBER
21. V-Sync renderer attached?          BOOLEAN
22. in-page crash detection capability TEXT
23. release graphics failsafe after MENGINE recovery COMMAND

Severity values
---------------
0 = no pending fault / no severity
1 = minor error (reserved; not currently emitted)
2 = normal error (reserved; not currently emitted)
3 = potentially serious (slow draw streak / visible RAF response delay)
4 = actual serious error (reserved for future specific, reliable detector)
5 = component failure (renderer exception, renderer reattach failure,
    WebGL context creation failure)
6 = critical fault (WebGL context loss)
7 = critical system fault (NOT inferred by this extension)
8 = critical page fault (NOT detectable by in-page JavaScript)

Fault codes currently emitted
------------------------------
WEBGL_CONTEXT_LOST              level 5
WEBGL_CONTEXT_CREATION_FAILED   level 4
RENDERER_DRAW_EXCEPTION         level 4
RENDERER_REATTACH_FAILED        level 4
SLOW_DRAW_STREAK                level 2
RAF_RESPONSE_DELAY              level 2

MENGINE integration notes
--------------------------
- Check `graphics fault pending?` first.
- Read level, code, message, sequence, and JSON before acknowledging.
- Prefer `acknowledge graphics faults through sequence [SEQUENCE]` using the
  sequence value MENGINE actually read. This avoids acknowledging a newer fault
  that arrives while MENGINE is processing the earlier one.
- Use the numeric level to feed MENGINE's existing if/else severity logic.
- Acknowledgement only marks events as seen. It does NOT clear a failsafe,
  erase the fault history, restore WebGL, or restart MMIC.
- For WEBGL_CONTEXT_LOST, treat level 5 as a graphics-critical fault: stop
  renderer-dependent work, log diagnostics, safely flush data using MENGINE's
  existing storage transaction handling, then perform the configured restart.
  A WebGL context loss alone is NOT proof of IndexedDB corruption, so the
  extension deliberately does not assign level 6.
- The extension latches a draw failsafe on a context loss or renderer exception:
  it cancels pending RAF work and keeps its renderer.draw wrapper as a guard,
  suppressing further calls into the failed renderer.
- `release graphics failsafe after MENGINE recovery` may only be called after
  MENGINE has rebuilt/validated renderer resources. It releases the draw guard
  and leaves V-Sync disabled; it does not rebuild renderer resources itself.
- `disable display-synchronized rendering` does not remove the guard while a
  critical fault is latched. This is intentional to avoid calling the failed
  original renderer during recovery.

Thresholds
----------
- A renderer draw taking at least 100 ms is counted as a slow draw.
- Three consecutive slow draws emit SLOW_DRAW_STREAK (level 2).
- A draw request waiting at least 1000 ms for its RAF callback while the page is
  visible emits RAF_RESPONSE_DELAY (level 2).
- Performance warnings are rate-limited to one every 10 seconds.
These are initial diagnostic thresholds, not universal failure boundaries.

Important detection limitations
--------------------------------
- The extension detects WebGL context loss through the context-loss event and
  isContextLost(). It does not poll gl.getError(), because getError() consumes
  entries from the shared WebGL error queue.
- Draw duration is synchronous JavaScript time; it does not measure total GPU
  execution time or physical monitor presentation time.
- RAF response-delay detection can only report a stall after JavaScript resumes.
- A browser/tab process crash, GPU-process hard hang that prevents all page JS,
  or a critical page failure that stops execution cannot be detected or handled
  by code running inside that same page. An external browser/host watchdog is
  required for that category.
- The extension does not write to IndexedDB, localStorage, project saves, or
  MediaCentre caches, and does not disconnect storage APIs. MENGINE retains
  ownership of safe-save and storage lockdown decisions.

Installation and test
---------------------
1. Back up the known-good v0.4.2 packaged MMIC build.
2. Remove/disable v0.4.2 before loading v0.4.3. Do not run both.
3. Load this JavaScript as an unsandboxed JavaScript V2 extension.
4. Keep interpolation disabled and retain the existing 240 TPS project setting.
5. First confirm normal operation and that all new reporters load.
6. In MENGINE, poll `graphics fault pending?` every 10 VM frames, and only when
   true read the severity/code/message/JSON/history. Acknowledge after MENGINE
   has recorded the event and made its recovery decision.
7. Do not intentionally lose the production renderer context during normal
   stress testing. A dedicated disposable test build can later simulate context
   loss with WEBGL_lose_context if desired; never run that destructive test in
   the live MMIC data environment.

This build has passed JavaScript syntax and mock-runtime behavior tests. It has
not yet been tested in the user's packaged PenguinMod/MMIC environment.

Suggested MENGINE polling pattern
--------------------------------
Inside MENGINE's existing every-10-frames diagnostic check:

IF <graphics fault pending?> THEN
    SET snapshotSequence TO (graphics fault sequence number)
    SET faultLevel TO (graphics fault severity level)
    SET faultCode TO (graphics fault code)
    SET faultMessage TO (graphics fault message)
    SET faultJSON TO (graphics fault details JSON)
    LOG the captured code, level, message, sequence, and JSON

    IF <faultLevel = 6> THEN
        Run MENGINE's critical-fault path (safe-save, then controlled MMIC restart)
    ELSE IF <faultLevel = 5> THEN
        Run MENGINE's component-failure path
    ELSE IF <faultLevel = 3> THEN
        Run MENGINE's potentially-serious/performance-warning path
    ELSE
        Route other values through MENGINE's existing severity policy
    END

    AFTER the fault has been logged and its action decided:
        acknowledge graphics faults through sequence (snapshotSequence)
END

The sequence-specific acknowledgement is preferred over the no-argument
acknowledgement because it cannot clear a newer fault that arrived while
MENGINE was processing the snapshot.
